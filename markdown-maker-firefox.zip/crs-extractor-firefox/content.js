// content.js — works on any page; extracts enhanced CRS metadata on Congress.gov
// Firefox/Chrome compatibility shim
if (typeof browser === 'undefined') var browser = chrome;

const IS_CONGRESS_GOV = window.location.hostname === 'www.congress.gov';
const IS_CRS_REPORTS  = window.location.hostname === 'crsreports.congress.gov';
const IS_CRS_PAGE     = IS_CONGRESS_GOV || IS_CRS_REPORTS;

function extractVersion() {
  // Pull version from PDF download link, e.g.:
  // https://crsreports.congress.gov/crs_external_products/IF/PDF/IF13200/IF13200.1.pdf
  // The version is the number after the second dot before .pdf
  const links = document.querySelectorAll('a[href*=".pdf"]');
  for (const link of links) {
    const href = link.getAttribute('href');
    const match = href.match(/\/[A-Z]{1,3}\d{4,6}\.(\d+)\.pdf/i);
    if (match) return match[1];
  }
  return '';
}

function extractReport() {
  const result = {
    title: '',
    reportNumber: '',
    version: '',
    date: '',
    authors: '',
    productType: '',
    topics: '',
    bodyMarkdown: '',
    bodyText: '',
    url: window.location.href,
    error: null
  };

  try {
    if (IS_CONGRESS_GOV) {
      extractCongressGov(result);
    } else if (IS_CRS_REPORTS) {
      extractCrsReports(result);
    } else {
      extractGeneric(result);
    }
  } catch (e) {
    result.error = 'Extraction failed: ' + e.message;
  }

  return result;
}

// --- congress.gov/crs-product layout ---
function extractCongressGov(result) {
  // Title
  const titleEl =
    document.querySelector('h1.legDetail') ||
    document.querySelector('.crs-product h1') ||
    document.querySelector('h1');
  if (titleEl) result.title = titleEl.innerText.trim();

  // Report number: from URL (most reliable)
  const urlMatch = window.location.pathname.match(/\/crs-product\/([A-Z]{1,3}\d{4,6})/i);
  if (urlMatch) result.reportNumber = urlMatch[1].toUpperCase();

  // Version: from PDF download link
  result.version = extractVersion();

  // Metadata: parse all rows from .overview_wrapper table
  const overviewRows = document.querySelectorAll('.overview_wrapper table.standard01 tr');
  overviewRows.forEach(row => {
    const th = row.querySelector('th');
    const td = row.querySelector('td');
    if (!th || !td) return;
    const key = th.innerText.trim().replace(/:$/, '');
    const val = td.innerText.trim();
    switch (key) {
      case 'Publication Date': result.date = val; break;
      case 'Author':           result.authors = val; break;
      case 'CRS Product Type': result.productType = val; break;
      case 'CRS Product Number': result.reportNumber = val; break;
      case 'Topics':           result.topics = val; break;
    }
  });

  // Body: congress.gov renders CRS content inside a main content region.
  // Try specific CRS product containers first, fall back to main.
  const bodyEl =
    document.querySelector('.crs-product-content') ||
    document.querySelector('.product-content') ||
    document.querySelector('[class*="crs-content"]') ||
    document.querySelector('[class*="report-body"]') ||
    document.querySelector('#main-content') ||
    document.querySelector('main') ||
    document.querySelector('.content-wrapper');

  if (!bodyEl) {
    result.error = 'No report body found on this page. If you see the report text in your browser, open the browser console (F12), go to the Elements tab, and let me know the class name on the element wrapping the report text—I can add it.';
    return;
  }

  // Exclude nav/sidebar elements that may be inside main
  const clone = bodyEl.cloneNode(true);
  clone.querySelectorAll('nav, .sidebar, .breadcrumb, [class*="sidebar"], [class*="nav-"], footer, .search-bar').forEach(el => el.remove());

  result.bodyMarkdown = nodeToMarkdown(clone);
  result.bodyText = clone.innerText.replace(/\n{3,}/g, '\n\n').trim();

  // If body text is very short, the selectors probably missed — report it
  if (result.bodyText.length < 200 && !result.error) {
    result.error = 'Extracted text is very short—the page structure may have changed. Check the console note above, or try the HTML report view at crsreports.congress.gov.';
  }
}

// --- crsreports.congress.gov layout ---
function extractCrsReports(result) {
  const titleEl =
    document.querySelector('h1.report-title') ||
    document.querySelector('.report-header h1') ||
    document.querySelector('h1[class*="title"]') ||
    document.querySelector('h1');
  if (titleEl) result.title = titleEl.innerText.trim();

  const reportNumEl =
    document.querySelector('.report-number') ||
    document.querySelector('[class*="report-number"]') ||
    document.querySelector('.product-number');
  if (reportNumEl) {
    result.reportNumber = reportNumEl.innerText.trim();
  } else {
    const match = window.location.href.match(/\/([A-Z]{1,3}\d{4,6})/i) ||
                  document.body.innerText.match(/\b([A-Z]{1,3}\d{4,6})\b/);
    if (match) result.reportNumber = match[1].toUpperCase();
  }

  const dateEl =
    document.querySelector('.report-date') ||
    document.querySelector('[class*="publish-date"]') ||
    document.querySelector('time');
  if (dateEl) result.date = (dateEl.getAttribute('datetime') || dateEl.innerText).trim();

  const authorEls = document.querySelectorAll('.author-name, .report-author, [class*="author"]');
  if (authorEls.length) {
    result.authors = Array.from(authorEls).map(el => el.innerText.trim()).filter(Boolean).join(', ');
  }

  // Version: from PDF download link
  result.version = extractVersion();

  const bodyEl =
    document.querySelector('.report-content') ||
    document.querySelector('article') ||
    document.querySelector('[class*="report-text"]') ||
    document.querySelector('main');

  if (!bodyEl) {
    result.error = 'No report body found. Make sure you are on a CRS report page that displays the full text, not just a landing page.';
    return;
  }

  result.bodyMarkdown = nodeToMarkdown(bodyEl);
  result.bodyText = bodyEl.innerText.replace(/\n{3,}/g, '\n\n').trim();
}

// --- Generic extractor for any page ---
function extractGeneric(result) {
  // Title from page title or h1
  const h1 = document.querySelector('h1');
  result.title = (h1 ? h1.innerText : document.title).trim();

  // Best-effort body: article > main > body, stripping nav/header/footer/aside
  const bodyEl =
    document.querySelector('article') ||
    document.querySelector('main') ||
    document.querySelector('[role="main"]') ||
    document.body;

  const clone = bodyEl.cloneNode(true);
  clone.querySelectorAll('nav, header, footer, aside, script, style, [class*="sidebar"], [class*="nav-"], [class*="menu"], [class*="cookie"], [class*="banner"], [class*="ad-"]').forEach(el => el.remove());

  result.bodyMarkdown = nodeToMarkdown(clone);
  result.bodyText = clone.innerText.replace(/\n{3,}/g, '\n\n').trim();
}

// --- Markdown converter ---
function nodeToMarkdown(el) {
  let md = '';

  function walk(node, context) {
    if (node.nodeType === Node.TEXT_NODE) {
      const text = node.textContent.replace(/\n/g, ' ');
      if (text.trim()) md += text;
      return;
    }
    if (node.nodeType !== Node.ELEMENT_NODE) return;

    const tag = node.tagName.toLowerCase();
    const inner = () => { node.childNodes.forEach(c => walk(c, tag)); };

    // Skip nav, scripts, styles, buttons, footnote markers
    if (['script','style','nav','button','aside'].includes(tag)) return;

    switch (tag) {
      case 'h1': md += '\n\n# '; inner(); md += '\n\n'; break;
      case 'h2': md += '\n\n## '; inner(); md += '\n\n'; break;
      case 'h3': md += '\n\n### '; inner(); md += '\n\n'; break;
      case 'h4': md += '\n\n#### '; inner(); md += '\n\n'; break;
      case 'h5': md += '\n\n##### '; inner(); md += '\n\n'; break;
      case 'p':  md += '\n\n'; inner(); md += '\n\n'; break;
      case 'br': md += '  \n'; break;
      case 'strong':
      case 'b':  md += '**'; inner(); md += '**'; break;
      case 'em':
      case 'i':  md += '_'; inner(); md += '_'; break;
      case 'a': {
        const href = node.getAttribute('href');
        const text = node.innerText.trim();
        if (href && text) {
          const abs = href.startsWith('http') ? href : 'https://crsreports.congress.gov' + href;
          md += `[${text}](${abs})`;
        } else {
          inner();
        }
        break;
      }
      case 'ul': md += '\n'; inner(); md += '\n'; break;
      case 'ol': md += '\n'; inner(); md += '\n'; break;
      case 'li': md += '\n- '; inner(); break;
      case 'table': md += '\n\n'; inner(); md += '\n\n'; break;
      case 'tr': inner(); md += '\n'; break;
      case 'th': md += '| **' + node.innerText.trim() + '** '; break;
      case 'td': md += '| ' + node.innerText.trim() + ' '; break;
      case 'blockquote': md += '\n\n> '; inner(); md += '\n\n'; break;
      case 'hr': md += '\n\n---\n\n'; break;
      case 'sup': break; // skip footnote superscripts
      default: inner(); break;
    }
  }

  walk(el, null);
  return md.replace(/\n{4,}/g, '\n\n').trim();
}

// Listen for messages from popup
browser.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'extract') {
    sendResponse(extractReport());
  }
});
