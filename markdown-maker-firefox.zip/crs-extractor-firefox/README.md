# CRS Report Extractor — Chrome Extension

Extracts CRS report content from **crsreports.congress.gov** as Markdown or plain text.
Runs entirely in your browser—no server, no scraping, no external calls.

---

## Installation (Arc / Chrome / Edge — Developer Mode)

1. Unzip this folder somewhere permanent (e.g. `~/tools/crs-extractor`)
2. Open Arc → navigate to `arc://extensions` (or `chrome://extensions`)
3. Enable **Developer mode** (toggle, top-right)
4. Click **Load unpacked**
5. Select the `crs-extractor` folder
6. The extension icon appears in your toolbar

To pin it: click the puzzle-piece icon → pin CRS Report Extractor.

---

## Usage

1. Navigate to any CRS report on **crsreports.congress.gov**
   - Works on HTML report pages (the ones that render the full text in-browser)
   - Also works on landing pages that link to the report HTML
2. Click the extension icon
3. Click **Extract Report**
4. Use any of the four output buttons:
   - **↓ Download .md** — saves a Markdown file
   - **↓ Download .txt** — saves a plain text file
   - **⎘ Copy Markdown** — copies to clipboard
   - **⎘ Copy Plain Text** — copies to clipboard

The output includes a metadata header (title, report number, date, authors, source URL)
followed by the full report body.

---

## Notes on CRS Page Types

CRS reports are available in two ways on Congress.gov:

- **HTML version** (best for extraction): the report renders in the browser as a webpage.
  URL pattern: `https://crsreports.congress.gov/product/details?prodcode=RXXXXX`
- **PDF only**: some older reports only have PDFs. This tool won't extract from PDFs—
  use the PDF download and run it through a PDF→text converter separately.

If extraction returns no body content, you're likely on a landing/search page rather
than a rendered report page. Click through to the full report HTML view first.

---

## Token efficiency tip

Plain text output is the most token-efficient format for pasting into Claude.
Markdown preserves heading structure (useful for long reports with many sections).
For short In Focus or Insight products, plain text is almost always sufficient.

---

## Files

```
crs-extractor/
├── manifest.json      Chrome extension manifest (MV3)
├── content.js         Content script: DOM extraction + Markdown converter
├── popup.html         Extension popup UI
├── popup.js           Popup logic: messaging, downloads, clipboard
├── icons/
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md          This file
```
