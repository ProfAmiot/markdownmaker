// popup.js

let extracted = null;

const statusDot = document.getElementById('status-dot');
const statusText = document.getElementById('status-text');
const metaSection = document.getElementById('meta');
const downloadBtns = document.getElementById('download-btns');
const wordCountEl = document.getElementById('word-count');

function setStatus(state, message) {
  statusDot.className = 'dot ' + state;
  statusText.className = 'status-text ' + state;
  statusText.textContent = message;
}

function buildHeader(data, format) {
  const lines = [];
  if (format === 'md') {
    lines.push(`# ${data.title || 'CRS Report'}`);
    lines.push('');
    if (data.productType)  lines.push(`**Product Type:** ${data.productType}`);
    if (data.reportNumber) lines.push(`**Report No.:** ${data.reportNumber}`);
    if (data.version)      lines.push(`**Version:** ${data.version}`);
    if (data.date)         lines.push(`**Publication Date:** ${data.date}`);
    if (data.authors)      lines.push(`**Author(s):** ${data.authors}`);
    if (data.topics)       lines.push(`**Topics:** ${data.topics}`);
    if (data.url)          lines.push(`**Source:** ${data.url}`);
    lines.push('');
    lines.push('---');
    lines.push('');
  } else {
    lines.push(data.title || 'CRS Report');
    lines.push('');
    if (data.productType)  lines.push(`Product Type: ${data.productType}`);
    if (data.reportNumber) lines.push(`Report No.: ${data.reportNumber}`);
    if (data.version)      lines.push(`Version: ${data.version}`);
    if (data.date)         lines.push(`Publication Date: ${data.date}`);
    if (data.authors)      lines.push(`Author(s): ${data.authors}`);
    if (data.topics)       lines.push(`Topics: ${data.topics}`);
    if (data.url)          lines.push(`Source: ${data.url}`);
    lines.push('');
    lines.push('---');
    lines.push('');
  }
  return lines.join('\n');
}

function buildFilename(data, ext) {
  const num = data.reportNumber ? data.reportNumber.replace(/[^a-zA-Z0-9]/g, '') : 'crs';
  const ver = data.version ? `v${data.version}` : '';
  const title = (data.title || 'report')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 48);
  return ver ? `${num}${ver}-${title}.${ext}` : `${num}-${title}.${ext}`;
}

function download(content, filename, mime) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

async function copyToClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    // Fallback
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    const ok = document.execCommand('copy');
    document.body.removeChild(ta);
    return ok;
  }
}

function showMeta(data) {
  document.getElementById('meta-title').textContent = data.title || '—';
  document.getElementById('meta-number').textContent = data.reportNumber || '—';
  document.getElementById('meta-date').textContent = data.date || '—';
  document.getElementById('meta-authors').textContent = data.authors || '—';
  metaSection.classList.add('visible');
}

function countWords(text) {
  return text.trim().split(/\s+/).filter(Boolean).length;
}

const IS_CRS_URL = (url) =>
  url.includes('crsreports.congress.gov') || url.match(/congress\.gov\/crs-product/);

// Auto-extract (and auto-download .md) when popup opens
chrome.tabs.query({ active: true, currentWindow: true }, async ([tab]) => {
  if (!tab || !tab.url || tab.url.startsWith('chrome://') || tab.url.startsWith('arc://')) {
    setStatus('error', 'Cannot run on browser pages');
    document.getElementById('btn-extract').disabled = true;
    return;
  }

  setStatus('loading', 'Extracting…');
  document.getElementById('btn-extract').disabled = true;

  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['content.js']
    }).catch(() => {});

    const response = await new Promise((resolve, reject) => {
      chrome.tabs.sendMessage(tab.id, { action: 'extract' }, (res) => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve(res);
      });
    });

    if (response.error) {
      setStatus('error', response.error);
      document.getElementById('btn-extract').disabled = false;
      return;
    }

    extracted = response;
    showMeta(extracted);

    const words = countWords(extracted.bodyText);
    wordCountEl.textContent = `~${words.toLocaleString()} words extracted`;
    wordCountEl.style.display = 'block';

    downloadBtns.style.display = 'grid';
    document.getElementById('btn-extract').textContent = 'Re-extract';
    document.getElementById('btn-extract').disabled = false;
    setStatus('ready', 'Extraction complete');

    // Auto-download .md
    const content = buildHeader(extracted, 'md') + extracted.bodyMarkdown;
    download(content, buildFilename(extracted, 'md'), 'text/markdown');

  } catch (e) {
    setStatus('error', 'Error: ' + e.message);
    document.getElementById('btn-extract').disabled = false;
  }
});

// Re-extract button (manual retry)
document.getElementById('btn-extract').addEventListener('click', async () => {
  setStatus('loading', 'Extracting…');
  document.getElementById('btn-extract').disabled = true;

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['content.js']
    }).catch(() => {});

    const response = await new Promise((resolve, reject) => {
      chrome.tabs.sendMessage(tab.id, { action: 'extract' }, (res) => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve(res);
      });
    });

    if (response.error) {
      setStatus('error', response.error);
      document.getElementById('btn-extract').disabled = false;
      return;
    }

    extracted = response;
    showMeta(extracted);

    const words = countWords(extracted.bodyText);
    wordCountEl.textContent = `~${words.toLocaleString()} words extracted`;
    wordCountEl.style.display = 'block';

    downloadBtns.style.display = 'grid';
    document.getElementById('btn-extract').disabled = false;
    setStatus('ready', 'Extraction complete');

  } catch (e) {
    setStatus('error', 'Error: ' + e.message);
    document.getElementById('btn-extract').disabled = false;
  }
});
// Download markdown
document.getElementById('btn-md').addEventListener('click', () => {
  if (!extracted) return;
  const content = buildHeader(extracted, 'md') + extracted.bodyMarkdown;
  download(content, buildFilename(extracted, 'md'), 'text/markdown');
  setStatus('ready', 'Downloaded .md');
});

// Download txt
document.getElementById('btn-txt').addEventListener('click', () => {
  if (!extracted) return;
  const content = buildHeader(extracted, 'txt') + extracted.bodyText;
  download(content, buildFilename(extracted, 'txt'), 'text/plain');
  setStatus('ready', 'Downloaded .txt');
});

// Copy markdown
document.getElementById('btn-copy-md').addEventListener('click', async () => {
  if (!extracted) return;
  const content = buildHeader(extracted, 'md') + extracted.bodyMarkdown;
  const ok = await copyToClipboard(content);
  setStatus('ready', ok ? 'Copied markdown ✓' : 'Copy failed');
});

// Copy plain text
document.getElementById('btn-copy-txt').addEventListener('click', async () => {
  if (!extracted) return;
  const content = buildHeader(extracted, 'txt') + extracted.bodyText;
  const ok = await copyToClipboard(content);
  setStatus('ready', ok ? 'Copied plain text ✓' : 'Copy failed');
});
